#-*- coding:utf-8 -*-
from wxpy import *

bot = Bot()
my_friend = bot.friends()
group = bot.groups()

myself = bot.self
print('微信记录')
@bot.register()
def print_messages(msg):
    print(msg)
    if msg.member != None:
        chat= str(msg.chat)+str(msg.member)
    else:
        chat = msg.chat
    message = str(msg.receive_time)+' '+chat+':'+msg.text+'\r\n'
    with open('wx.txt','a') as f:
        f.write(message.encode('gbk').decode('gbk'))

embed()